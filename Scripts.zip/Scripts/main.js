
import javascriptLogo from './javascript.svg'
import { setupCounter } from './counter.js'
import  Party  from "./game.js"
import Engine from './Engine'


console.log(( Party).BuildRandomMaze(35,20))

Party.RunGame()


window.PARTY = Party
