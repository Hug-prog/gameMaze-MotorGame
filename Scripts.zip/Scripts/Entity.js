export default class entity
{
    id     = 0;
    name   = ""
    health = 0;
    attack = 0;
    X   = 0;
    Y   = 0
    Spawned = false;

    constructor(id, name, health, attack, posX, posY) {
        this.id = id;
        this.name = name;
        this.health = health;
        this.attack = attack;
        this.posX = posX;
        this.posY = posY;
      }
    
      // get
      getId() {
        return this.id;
      }
    
      getName() {
        return this.name;
      }
    
      getHealth() {
        return this.health;
      }
    
      getAttack() {
        return this.attack;
      }
    
      getPosX() {
        return this.X;
      }
    
      getPosY() {
        return this.Y;
      }
    
      //set
    
      setHealth(health) {
        this.health = health;
      }
    
      setAttack(attack) {
        this.attack = attack;
      }
    
      setPosX(posX) {
        this.X = posX;
      }
    
      setPosY(posY) {
        this.Y = posY;
      }
}