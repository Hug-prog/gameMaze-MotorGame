export default class Engine
{
    static RAYCAST = 
    {
        up: 0,
        right: 1,
        bottom: 2,
        left: 3,

        INF : 99999
    };

    static RayCast(matrice, start = { x: 0, y: 0 }, RaySize, direction) {
        if (direction == RAYCAST.up) {
          for (let x = 1; x <= RaySize; x++) {
            if (matrice[start.y - x] != undefined) {
              if (matrice[start.y - x][start.x] == 0)
                return { position: { x: start.x, y: (start.y - x) }, col: true };
            }
          }
        } else if (direction == RAYCAST.right) {
          for (let x = 1; x < RaySize; x++) {
            if (matrice[start.y][start.x + x] != undefined) {
              if (matrice[start.y][start.x + x] == 0)
                return { position: { x: (start.x + x), y: start.y }, col: true };
            }
          }
        }else if (direction == RAYCAST.left) {
            for (let x = 1; x < RaySize; x++) {
              if (matrice[start.y][start.x - x] != undefined) {
                if (matrice[start.y][start.x - x] == 0)
                  return { position: { x: (start.x - x), y: start.y }, col: true };
              }
            }
          }else if (direction == RAYCAST.bottom) {
            for (let x = 1; x < RaySize; x++) {
              if (matrice[start.y+x][start.x] != undefined) {
                if (matrice[start.y+x][start.x] == 0)
                  return { position: { x: start.x, y: (start.y + x) }, col: true };
              }
            }
          }
      
        return { position: { x: start.x, y: start.y }, col: false };
      }

}