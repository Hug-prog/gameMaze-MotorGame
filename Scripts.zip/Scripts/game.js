
import Player from "./Player.js"
import Bot from "./Bot.js";
import entity from "./Entity.js";

const sleep = (ms) =>  new Promise(resolve => setTimeout(resolve, ms));

export default new class Party
{
    #render  = false
    #bot_run = false
    #bots    = []

    #frame_rate = (120000/1000)

    #CONSTROL = {
      up: "z",
      left: "q",
      right: "d",
      bottom: "s",
    };
    


    #maze = []

    #width  = 0;
    #height = 0

    SetFrameRate(fps)
    {
        this.#frame_rate = (fps/1000)
    }

    GetFrameRate()
    {
        return this.#frame_rate;
    }

    GetWidth()
    {
        return this.#width
    }

    GetHeight()
    {
        return this.#height
    }


    SetMaze(matrice)
    {
        this.#maze = matrice

        return this;
    }

    GetMaze()
    {
        return this.#maze
    }

    #Draw()
    {
        this.#maze.forEach(vh =>
            {
                var ligne = "<tr>";
          
                vh.forEach(vw =>
                {
                    if (vw == 1) {
                        ligne += "<td></td>";
                      } else if (vw == "p") {
                        ligne += '<td bgcolor="orange" alt=""></td>';
                      } else if (vw == "b") {
                        ligne += '<td bgcolor="red" alt=""></td>';
                      } else {
                        ligne += '<td bgcolor="black" alt=""></td>';
                      }
                })
          
                document
                .getElementById("monLabyrinthe")
                .insertAdjacentHTML("beforeEnd", ligne);
        })
    }

    #Clear()
    {
        Object.values(document.getElementById("monLabyrinthe").getElementsByTagName("tr")).forEach(v=>v.remove())
    }

    #Render()
    {
        return (async ()=> {
            do
            {
                this.#Draw();
                await sleep(this.#frame_rate)
                this.#Clear()


            }  while(this.#render);

            this.#Draw();

            
          })()
         
    }

    StartRender()
    {
       this.#render = true

       this.#Render();

       return this;

    }

    StopRender()
    {
       this.#render = false

       return this;
    }

    BuildRandomMaze(w,h)
    {
        this.#width = w;
        this.#height = h

        const _m = {};
        _m.matrice  = []

        for (let _h = 0; _h < h; _h++) {
            _m.matrice[_h] = [];
      
            _m.matrice[_h].push(0);
      
          for (let _w = 0; _w < w; _w++) {
            if (_h == 0 || _w == w - 1 || _h == h - 1) {
              _m.matrice[_h].push(0);
            } else _m.matrice[_h].push(0);
          }
        }
      
        // Parcour les colonne
        _m.matrice.forEach((_eh, ih) => {
          // Parcour les ligne
          _eh.forEach((_ew, iw) => {
            // Check si il est plus grand que 0  et plus petit que la taille de la matrice (pour les bord)
            if (iw > 0 && ih > 0 && iw < _m.matrice[0].length - 2 && ih < _m.matrice.length - 2) {
              // Verifie si c'est de "2 en 2"
              if (ih % 2 || iw % 2) {
                // Si c'est la cas alors c'est un carré blanc (vide)
                _m.matrice[ih][iw] = 1;
              }
            }
      
            // Pour eliminer la surcouche des bord
            if (iw == _m.matrice[0].length - 1 || ih == _m.matrice.length - 1) _m.matrice[ih][iw] = 1;
          });
        });
      
        // J'ai essayé de concatener ce qui suit dans la première iteration mais j'y arrive pas
        
        // Parcour les colonne
        _m.matrice.forEach((_eh, ih) => {
          // Parcour les ligne
          _eh.forEach((_ew, iw) => {
            // Random Position (pour plus tard)
            let CRandom = RandomNumber(0, 3);
      
            // Check si il est plus grand que 0  et plus petit que la taille de la matrice (pour les bord)
            if (iw > 0 && ih > 0 && iw < (_m.matrice[0].length - 2) && ih < (_m.matrice.length - 2)) {

                if(ih >= Player.Y && iw >= Player.X && !Player.Spawned  && ((ih % 2) && (iw % 2)))
                {
                    Player.Y = ih
                    Player.X = iw
                    _m.matrice[ih][iw] = "p"
                    Player.Spawned = true
                }

              // Verifie si ce n'est de "2 en 2" (pour être sur les carré noir)
              if (!(ih % 2) && !(iw % 2)) {
                // Si CRandom est egal 0 alors il y a un carré noir au dessus de celui actuellement
                if (CRandom == 0) {
                  _m.matrice[ih - 1][iw] = 0;
      
                  // Si CRandom est egal 1 alors il y a un carré noir juste a droite de celui actuellement
                } else if (CRandom == 1) {
                  _m.matrice[ih][iw + 1] = 0;
      
                  // Si CRandom est egal 2 alors il y a un carré noir en dessous de celui actuellement
                } else if (CRandom == 2) {
                  _m.matrice[ih + 1][iw] = 0;
      
                  // Si CRandom est egal 2 alors il y a un carré noir juste a gauche de celui actuellement
                } else if (CRandom == 3) {
                  _m.matrice[ih][iw - 1] = 0;
                }
              }
            }
          });
        });

        this.#maze = _m.matrice
      
        return _m;

    }

    #RunBots()
    {

      return (async ()=> {
        let direction = ["up", "down", "left", "right"];
        do
        {
            for(let bot of this.#bots)
            {

            }

            await sleep(this.#frame_rate)
            this.#Clear()


        }  while(this.#bot_run);

        this.#Draw();

        
      })()
     
    }

    StartBots()
    {
      this.#bot_run = true
      this.#RunBots();

    }

    StopBots()
    {
      this.#bot_run = false
    }

    SpawnBot(n=null)
    {
        if(this.#maze.length==0)
            return 0
        
        if(n!=null)
          Bot.NumberOfBots = n
        else
          n = Bot.NumberOfBots


        for(let x = 0;x <= Bot.NumberOfBots;x++)
        {
          console.log("TEST")
           let TempBotPos = {x: RandomNumber(1,this.#width-2), y: RandomNumber(1,this.#height-2)}
           
           console.log(" TempBotPos = ",TempBotPos)

          this.#maze.forEach((_eh, ih) => {
            // Parcour les ligne
            _eh.forEach((_ew, iw) => {
              // Check si il est plus grand que 0  et plus petit que la taille de la matrice (pour les bord)
              if (iw > 0 && ih > 0 && iw < this.#maze[0].length - 2 && ih < this.#maze.length - 2) {

                if(TempBotPos==null)
                    return
                // Verifie si c'est de "2 en 2"
                if (_ew == 1 && (ih >= TempBotPos.y && iw >= TempBotPos.x)) {

                      TempBotPos.x = iw;
                      TempBotPos.y = ih;

                      this.#bots.push(new Bot(null,x,"Bob",100,-10,TempBotPos.x,TempBotPos.y))
                  // Si c'est la cas alors c'est un carré blanc (vide)
                      this.#maze[ih][iw] = "b";
                      TempBotPos = null
                }
              }
    
            });
          });

          


        }

        return this
    }

    RunGame()
    {

      console.log("BOTS = ",this.SpawnBot())
      document.addEventListener("keydown", event => {
       
        if (event.key.toLowerCase() == CONSTROL.up && this.#maze[Player.Y - 1][Player.X] == 1) {
            this.#maze[Player.Y][Player.X] = 1;
            Player.Y -= 1
            this.#maze[Player.Y][Player.X] = "p";
        }
    
        // back
        if (event.key.toLowerCase() == CONSTROL.bottom && this.#maze[Player.Y + 1][Player.X] == 1) {
          this.#maze[Player.Y][Player.X] = 1;
          Player.Y += +1
            this.#maze[Player.Y][Player.X] = "p";
        }
    
        // left
        if (event.key.toLowerCase() == CONSTROL.left && this.#maze[Player.Y][Player.X  - 1] == 1) {
          this.#maze[Player.Y][Player.X] = 1;
          Player.X -= 1
            this.#maze[Player.Y][Player.X] = "p";
        }
    
        // right
        if (event.key.toLowerCase() == CONSTROL.right && this.#maze[Player.Y][Player.X + 1] == 1) {
          this.#maze[Player.Y][Player.X] = 1;
          Player.X += 1
          this.#maze[Player.Y][Player.X] = "p";
        }
        

      });

    //  this.StartBots();
      this.StartRender();
    }
}

